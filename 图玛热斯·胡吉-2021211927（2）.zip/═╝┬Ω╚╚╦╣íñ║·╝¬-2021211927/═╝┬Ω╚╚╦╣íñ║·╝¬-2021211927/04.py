import pandas as pd


data = {
    'AGE': [59, 48, 72, ...],
    'SEX': [2, 1, 2, ...],
    'BMI': [32.1, 21.6, 30.5, ...],
    'BP': [101.0, 87.0, 93.0, ...],
    'S1': [157, 183, 156, ...],
    'S2': [93.2, 103.2, 93.6, ...],
    'S3': [38.0, 70.0, 41.0, ...],
    'S4': [4.0, 3.0, 4.0, ...],
    'S5': [4.8598, 3.8918, 4.0, ...],
    'S6': [87, 69, 85, ...],
    'Y': [151, 75, 141, ...]
}

df = pd.DataFrame(data)


means = df.mean()
variances = df.var()

print("平均值：")
print(means)
print("\n方差：")
print(variances)



import seaborn as sns
import matplotlib.pyplot as plt


plt.figure(figsize=(10, 6))
sns.boxplot(x='SEX', y='BMI', data=df)
plt.title('BMI vs SEX')
plt.show()

plt.figure(figsize=(10, 6))
sns.boxplot(x='SEX', y='BP', data=df)
plt.title('BP vs SEX')
plt.show()

plt.figure(figsize=(10, 6))
sns.boxplot(x='SEX', y='Y', data=df)
plt.title('Y vs SEX')
plt.show()




plt.figure(figsize=(10, 6))
sns.histplot(df['AGE'], kde=True)
plt.title('AGE Distribution')
plt.show()

plt.figure(figsize=(6, 4))
sns.countplot(x='SEX', data=df)
plt.title('SEX Distribution')
plt.show()

plt.figure(figsize=(10, 6))
sns.histplot(df['BMI'], kde=True)
plt.title('BMI Distribution')
plt.show()

plt.figure(figsize=(10, 6))
sns.histplot(df['Y'], kde=True)
plt.title('Y Distribution')
plt.show()




correlation_matrix = df.corr()
print(correlation_matrix['Y'])


plt.figure(figsize=(10, 8))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Correlation Matrix')
plt.show()


from scipy import stats


male_data = df[df['SEX'] == 1]['Y']
female_data = df[df['SEX'] == 2]['Y']


t_stat, p_value = stats.ttest_ind(male_data, female_data)

print("t统计量:", t_stat)
print("P值:", p_value)


alpha = 0.05
if p_value < alpha:
    print("拒绝零假设：男性和女性糖尿病进展程度不同")
else:
    print("接受零假设：男性和女性糖尿病进展程度相似")