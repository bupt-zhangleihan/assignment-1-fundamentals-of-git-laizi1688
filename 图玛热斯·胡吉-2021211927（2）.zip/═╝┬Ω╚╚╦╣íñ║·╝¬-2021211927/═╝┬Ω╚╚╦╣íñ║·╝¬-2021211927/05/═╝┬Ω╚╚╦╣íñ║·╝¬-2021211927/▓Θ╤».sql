select city from Cities
