select city from cities
where country="Ireland"